export const DATA_EXPIRATION_TIME = 3600*1000;  // one hour
