export const server = {
  url: '/school',
  debug: true
};
