export const SEMESTER_WEEK_COUNT = 20;  // 20 weeks in one semester
export const TEST_HISTORY_BYTIME = false;
